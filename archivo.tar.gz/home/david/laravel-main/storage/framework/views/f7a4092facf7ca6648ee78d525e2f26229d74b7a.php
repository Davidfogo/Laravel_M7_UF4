<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>detail</h1>
    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <figure>
            <a><img src="<?php echo e(asset('images/'.$d->img)); ?>" alt="cocacola_imagen" ></a>
            <figcaption><?php echo e($d->name); ?> - <?php echo e($d->price); ?>€</figcaption>
            <figcaption></figcaption>
            <figcaption>KCAL x unidad: <?php echo e($d->kcal_por_unidad); ?></figcaption>
            <figcaption>KCAL x 100g: <?php echo e($d->kcal_por_100g); ?></figcaption>
            <figcaption>Grasas: <?php echo e($d->grasas); ?></figcaption>
            <figcaption>Carbohitrados: <?php echo e($d->carbohidratos); ?></figcaption>
            <figcaption>Proteinas: <?php echo e($d->proteinas); ?></figcaption>

            <div>
                <button><a href="<?php echo e(url('/waiting')); ?>">comprar</a></button>
                <button><a href="<?php echo e(url('/main')); ?>">volver</a></button>
            </div>
    </figure>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH /home/david/laravel-main/resources/views/detail.blade.php ENDPATH**/ ?>