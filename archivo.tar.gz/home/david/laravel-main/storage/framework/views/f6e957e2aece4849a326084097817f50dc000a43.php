<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .container{
            display: flex;
            flex-wrap:wrap;
        }

        figure{
            width:200px;
            height:350px;
        }

        img{
            width:100%;
            height:300px;
        }
    </style>
</head>
<body>
    <?php if(auth()->guard()->check()): ?>
    <?php echo e(auth()->user()->name); ?> - Saldo: 100€
    <?php endif; ?>
    <form action="<?php echo e(route('logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button>logiut</button>
    </form>
    <h1>main</h1>
    <div class="container">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <figure>
            <a href="<?php echo e(url('/detail/'.$product->id)); ?>"><img src="<?php echo e(asset('images/'.$product->img)); ?>" alt="cocacola_imagen" ></a>
            <figcaption><?php echo e($product->name); ?> - <?php echo e($product->price); ?>€</figcaption>
            <a href="<?php echo e(url('/detail/'.$product->id)); ?>"><img src="<?php echo e(asset('images/'.$product->img)); ?>" alt="cocacola_imagen" ></a>
            <figcaption><?php echo e($product->name); ?> - <?php echo e($product->price); ?>€</figcaption>
            <a href="<?php echo e(url('/detail/'.$product->id)); ?>"><img src="<?php echo e(asset('images/'.$product->img)); ?>" alt="cocacola_imagen" ></a>
            <figcaption><?php echo e($product->name); ?> - <?php echo e($product->price); ?>€</figcaption>
            
            

            
        </figure>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH /home/david/laravel-main/resources/views//main.blade.php ENDPATH**/ ?>