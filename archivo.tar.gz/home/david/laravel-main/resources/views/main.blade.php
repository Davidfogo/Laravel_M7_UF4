<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .container{
            display: flex;
            flex-wrap:wrap;
        }

        figure{
            width:200px;
            height:350px;
        }

        img{
            width:100%;
            height:300px;
        }
    </style>
</head>
<body>
    @auth
    {{ auth()->user()->name}} - Saldo: 100€
    @endauth
    <form action="{{route('logout')}}" method="post">
        @csrf
        <button>logiut</button>
    </form>
    <h1>main</h1>
    <div class="container">
        @foreach($products as $product)
        <figure>
            
            <a href="{{ url('/detail/'.$product->id)}}"><img src="{{ asset('images/'.$product->img)}}" alt="cocacola_imagen" ></a>
            <figcaption>{{$product->name}} - {{$product->price}}€</figcaption>

            <a href="{{ url('/detail/'.$product->id)}}"><img src="{{ asset('images/'.$product->img)}}" alt="cocacola_imagen" ></a>
            <figcaption>{{$product->name}} - {{$product->price}}€</figcaption>

            <a href="{{ url('/detail/'.$product->id)}}"><img src="{{ asset('images/'.$product->img)}}" alt="cocacola_imagen" ></a>
            <figcaption>{{$product->name}} - {{$product->price}}€</figcaption>
            
            

            
        </figure>
        @endforeach
    </div>
</body>
</html>