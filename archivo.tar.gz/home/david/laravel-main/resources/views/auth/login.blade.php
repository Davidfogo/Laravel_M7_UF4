<form action="{{'login'}}" method="POST">
    @csrf
    <input type="email" name="email" placeholder="enter email">
    @error('email') <div>{{$message}}</div>@enderror
    <input type="password" name="password" placeholder="enter password">
    @error('password') <div>{{$message}}</div>@enderror
    <button type="submit">login</button>
</form>