<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>detail</h1>
    @foreach($detail as $d)
    <figure>
            <a><img src="{{ asset('images/'.$d->img)}}" alt="cocacola_imagen" ></a>
            <figcaption>{{$d->name}} - {{$d->price}}€</figcaption>
            <figcaption></figcaption>
            <figcaption>KCAL x unidad: {{$d->kcal_por_unidad}}</figcaption>
            <figcaption>KCAL x 100g: {{$d->kcal_por_100g}}</figcaption>
            <figcaption>Grasas: {{$d->grasas}}</figcaption>
            <figcaption>Carbohitrados: {{$d->carbohidratos}}</figcaption>
            <figcaption>Proteinas: {{$d->proteinas}}</figcaption>

            <div>
                <button><a href="{{ url('/waiting')}}">comprar</a></button>
                <button><a href="{{ url('/main')}}">volver</a></button>
            </div>
    </figure>
    @endforeach
</body>
</html>