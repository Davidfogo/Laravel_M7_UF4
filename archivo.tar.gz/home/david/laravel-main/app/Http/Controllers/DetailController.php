<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Detail;

class DetailController extends Controller
{
    public function index($id){
       
        $detail = Detail::join('products', 'products.id', '=' , 'details.product_id')
                    ->where('product_id','=',$id)->get();

          return view('detail',compact('detail'));
    }
}
